package com.five.member.entity;

public class JobVO {

}
