package com.five.member.entity;

public class EmployVO {

	
	
	
	
}
