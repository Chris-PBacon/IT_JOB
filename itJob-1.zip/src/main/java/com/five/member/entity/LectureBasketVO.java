package com.five.member.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class LectureBasketVO {

	private int lb_seq;
	private int l_seq;
	private String m_id;
	
	
	
}
