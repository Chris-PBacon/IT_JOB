package com.five.member.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;

import com.five.member.entity.memberEVO;
import com.five.member.entity.memberNVO;

@Mapper
public interface JobMapper {

	

}
