package com.five.member;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItJob1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
